

function Fotter() {
  return (
    <>
      <div className=' pt-10 pb-36 px-10 bg-fuchsia-300  border-t-2  border-fuchsia-600 flex gap-6 flex-col'>
        <h1 className=" md:text-4xl text-3xl ">Abhinay_Ma</h1>
        <ul className="md:text-lg  text-md flex flex-col gap-3 ">
        <li className=" "><a href="">instagram</a></li>
        <li className=" "><a href="">Linked in</a></li>
        </ul>
      </div>
    </>
  )
}

export default Fotter
